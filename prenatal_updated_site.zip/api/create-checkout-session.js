const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);

/**
 * Netlify Function to create a Stripe Checkout Session for card payments.
 * Receives JSON body with finish, imageUrl and shipping info.
 * Responds with a checkout URL that the client should redirect to.
 */
exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method Not Allowed' };
  }
  try {
    const { finish, imageUrl, shipping } = JSON.parse(event.body);
    // Calculate total price (portrait + shipping) in cents
    const amount = 5999 + 699;
    const session = await stripe.checkout.sessions.create({
      mode: 'payment',
      line_items: [
        {
          price_data: {
            currency: 'usd',
            unit_amount: amount,
            product_data: {
              name: `Prenatal Portrait – ${finish}`,
              description: '3D Printed Baby Keepsake',
              images: imageUrl ? [imageUrl] : undefined,
            },
          },
          quantity: 1,
        },
      ],
      shipping_address_collection: { allowed_countries: ['US', 'CA'] },
      success_url: `${process.env.URL || 'https://prenatalportraits.com'}/success.html`,
      cancel_url: `${process.env.URL || 'https://prenatalportraits.com'}/shop.html`,
      metadata: {
        finish,
        imageUrl: imageUrl || '',
        ...shipping,
      },
    });
    return {
      statusCode: 200,
      body: JSON.stringify({ url: session.url }),
    };
  } catch (err) {
    console.error(err);
    return { statusCode: 500, body: JSON.stringify({ error: err.message }) };
  }
};