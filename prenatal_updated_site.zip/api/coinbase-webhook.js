const crypto = require('crypto');
const axios = require('axios');

/**
 * Coinbase Commerce webhook handler.
 * Verifies signature and sends order notification on charge confirmed/resolved.
 */
exports.handler = async (event) => {
  const signature = event.headers['x-cc-webhook-signature'] || event.headers['X-CC-Webhook-Signature'];
  const secret = process.env.COINBASE_WEBHOOK_SECRET;
  const payload = event.body;
  const computed = crypto.createHmac('sha256', secret).update(payload).digest('hex');
  if (signature !== computed) {
    console.error('Coinbase webhook signature mismatch');
    return { statusCode: 400, body: 'Signature mismatch' };
  }
  let webhookEvent;
  try {
    webhookEvent = JSON.parse(payload);
  } catch (err) {
    return { statusCode: 400, body: 'Invalid JSON payload' };
  }
  const eventType = webhookEvent.event && webhookEvent.event.type;
  if (eventType === 'charge:confirmed' || eventType === 'charge:resolved') {
    const meta = webhookEvent.event.data.metadata || {};
    // Compose email
    const to = process.env.ORDER_NOTIFICATION_TO;
    const from = process.env.FROM_EMAIL;
    const subject = `New Prenatal Portrait Crypto Order – ${meta.finish || ''}`;
    const html = `
      <h2>New Prenatal Portrait Order (Crypto)</h2>
      <p><strong>Finish:</strong> ${meta.finish || 'N/A'}</p>
      <p><strong>Image URL:</strong> ${meta.imageUrl || 'N/A'}</p>
      <p><strong>Name:</strong> ${meta.name || 'N/A'}</p>
      <p><strong>Email:</strong> ${meta.email || 'N/A'}</p>
      <p><strong>Address:</strong> ${meta.line1 || ''} ${meta.line2 || ''}, ${meta.city || ''}, ${meta.state || ''} ${meta.zip || ''}, ${meta.country || ''}</p>
    `;
    try {
      await axios.post('https://api.resend.com/emails', {
        from,
        to,
        subject,
        html
      }, {
        headers: {
          'Authorization': `Bearer ${process.env.RESEND_API_KEY}`,
          'Content-Type': 'application/json'
        }
      });
      console.log('Crypto order notification sent via Resend');
    } catch (err) {
      console.error('Failed to send crypto order email:', err.response ? err.response.data : err.message);
    }
  }
  return { statusCode: 200, body: 'Received' };
};