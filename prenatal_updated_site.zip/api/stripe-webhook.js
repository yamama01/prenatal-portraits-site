const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const axios = require('axios');

/**
 * Stripe webhook handler.
 * Listens for checkout.session.completed and sends an order notification via Resend.
 */
exports.handler = async (event) => {
  const sig = event.headers['stripe-signature'];
  const payload = event.body;
  let stripeEvent;
  try {
    stripeEvent = stripe.webhooks.constructEvent(payload, sig, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    console.error('Stripe webhook signature verification failed:', err.message);
    return { statusCode: 400, body: 'Webhook signature verification failed' };
  }
  // Only handle completed checkout sessions
  if (stripeEvent.type === 'checkout.session.completed') {
    const session = stripeEvent.data.object;
    const meta = session.metadata || {};
    // Compose email content
    const to = process.env.ORDER_NOTIFICATION_TO;
    const from = process.env.FROM_EMAIL;
    const subject = `New Prenatal Portrait Order – ${meta.finish || ''}`;
    const html = `
      <h2>New Prenatal Portrait Order</h2>
      <p><strong>Finish:</strong> ${meta.finish || 'N/A'}</p>
      <p><strong>Image URL:</strong> ${meta.imageUrl || 'N/A'}</p>
      <p><strong>Name:</strong> ${meta.name || 'N/A'}</p>
      <p><strong>Email:</strong> ${meta.email || 'N/A'}</p>
      <p><strong>Address:</strong> ${meta.line1 || ''} ${meta.line2 || ''}, ${meta.city || ''}, ${meta.state || ''} ${meta.zip || ''}, ${meta.country || ''}</p>
    `;
    try {
      await axios.post('https://api.resend.com/emails', {
        from,
        to,
        subject,
        html
      }, {
        headers: {
          'Authorization': `Bearer ${process.env.RESEND_API_KEY}`,
          'Content-Type': 'application/json'
        }
      });
      console.log('Order notification sent via Resend.');
    } catch (err) {
      console.error('Failed to send order email:', err.response ? err.response.data : err.message);
    }
  }
  return { statusCode: 200, body: 'Received' };
};