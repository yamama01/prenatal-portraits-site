const axios = require('axios');

/**
 * Netlify Function to create a Coinbase Commerce charge for crypto payments.
 * Receives JSON body with finish, imageUrl and shipping info.
 * Returns the hosted_url where the customer completes the crypto payment.
 */
exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method Not Allowed' };
  }
  try {
    const { finish, imageUrl, shipping } = JSON.parse(event.body);
    const payload = {
      name: `Prenatal Portrait – ${finish}`,
      description: '3D Printed Baby Keepsake',
      pricing_type: 'fixed_price',
      local_price: {
        amount: '66.98',
        currency: 'USD'
      },
      metadata: {
        finish,
        imageUrl: imageUrl || '',
        ...shipping,
      },
      redirect_url: `${process.env.URL || 'https://prenatalportraits.com'}/success.html`,
      cancel_url: `${process.env.URL || 'https://prenatalportraits.com'}/shop.html`,
    };
    const response = await axios.post('https://api.commerce.coinbase.com/charges', payload, {
      headers: {
        'Content-Type': 'application/json',
        'X-CC-Version': '2018-03-22',
        'X-CC-Api-Key': process.env.COINBASE_COMMERCE_API_KEY
      },
    });
    const hostedUrl = response.data?.data?.hosted_url;
    return {
      statusCode: 200,
      body: JSON.stringify({ hosted_url: hostedUrl }),
    };
  } catch (error) {
    console.error(error.response ? error.response.data : error.message);
    return { statusCode: 500, body: JSON.stringify({ error: 'Failed to create crypto charge' }) };
  }
};