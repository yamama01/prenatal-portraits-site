const axios = require('axios');

/**
 * Netlify Function to handle partner interest form submissions.
 * Accepts JSON with business-name, contact-name, email, phone and message.
 * Sends an email via Resend with the submitted details.
 */
exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method Not Allowed' };
  }
  try {
    const data = JSON.parse(event.body || '{}');
    const businessName = data['business-name'] || '';
    const contactName = data['contact-name'] || '';
    const email = data.email || '';
    const phone = data.phone || '';
    const message = data.message || '';
    // Compose email content
    const to = process.env.ORDER_NOTIFICATION_TO;
    const from = process.env.FROM_EMAIL;
    const subject = `New Partner Interest: ${businessName}`;
    const html = `
      <h2>New Partner Interest Submission</h2>
      <p><strong>Business Name:</strong> ${businessName}</p>
      <p><strong>Contact Name:</strong> ${contactName}</p>
      <p><strong>Email:</strong> ${email}</p>
      <p><strong>Phone:</strong> ${phone}</p>
      <p><strong>Message:</strong><br>${message.replace(/\n/g, '<br>')}</p>
    `;
    // Send email using Resend
    await axios.post('https://api.resend.com/emails', {
      from,
      to,
      subject,
      html
    }, {
      headers: {
        'Authorization': `Bearer ${process.env.RESEND_API_KEY}`,
        'Content-Type': 'application/json'
      }
    });
    return { statusCode: 200, body: JSON.stringify({ success: true }) };
  } catch (err) {
    console.error('Failed to handle partner interest:', err.response ? err.response.data : err.message);
    return { statusCode: 500, body: JSON.stringify({ error: 'Server error' }) };
  }
};