// Stripe webhook handler (placeholder)
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);

exports.handler = async function(event, context) {
  const sig = event.headers['stripe-signature'];
  let body = event.body;

  try {
    const stripeEvent = stripe.webhooks.constructEvent(body, sig, process.env.STRIPE_WEBHOOK_SECRET);
    // Handle event type (payment_intent.succeeded, checkout.session.completed, etc.)
    console.log('Stripe event received:', stripeEvent.type);
    return { statusCode: 200, body: 'Received' };
  } catch (err) {
    console.error(`Webhook error: ${err.message}`);
    return { statusCode: 400, body: `Webhook Error: ${err.message}` };
  }
};