const axios = require('axios');
const FormData = require('form-data');

/**
 * Netlify Function to proxy image uploads to Cloudinary.
 * Accepts JSON { dataUrl: 'data:image/png;base64,...' }
 * Returns Cloudinary upload response.
 */
exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method Not Allowed' };
  }
  try {
    const { dataUrl } = JSON.parse(event.body || '{}');
    if (!dataUrl) {
      return { statusCode: 400, body: JSON.stringify({ error: 'Missing dataUrl' }) };
    }
    // Extract base64 data and file type
    const matches = dataUrl.match(/^data:(image\/\w+);base64,(.+)$/);
    if (!matches) {
      return { statusCode: 400, body: JSON.stringify({ error: 'Invalid data URL' }) };
    }
    const mimeType = matches[1];
    const base64Data = matches[2];
    const buffer = Buffer.from(base64Data, 'base64');
    const extension = mimeType.split('/')[1];
    const formData = new FormData();
    formData.append('file', buffer, {
      filename: `upload.${extension}`,
      contentType: mimeType
    });
    formData.append('upload_preset', process.env.CLOUDINARY_UPLOAD_PRESET);
    // Post to Cloudinary
    const cloudName = process.env.CLOUDINARY_CLOUD_NAME;
    const response = await axios.post(`https://api.cloudinary.com/v1_1/${cloudName}/image/upload`, formData, {
      headers: formData.getHeaders()
    });
    return {
      statusCode: 200,
      body: JSON.stringify({ url: response.data.secure_url })
    };
  } catch (err) {
    console.error('Upload failed:', err.response ? err.response.data : err.message);
    return { statusCode: 500, body: JSON.stringify({ error: 'Image upload failed' }) };
  }
};