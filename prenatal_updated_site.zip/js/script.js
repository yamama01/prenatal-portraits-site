// script.js – global site functionality

// Utility to update the footer year
function setCurrentYear() {
    const yearEl = document.getElementById('year');
    if (yearEl) {
        yearEl.textContent = new Date().getFullYear();
    }
}

// Uploads an image to Cloudinary via our Netlify proxy.
// Converts a file into a data URL and posts it to /api/upload-image.
async function uploadImageToCloud(file) {
    // Convert file to base64 data URL
    const toDataUrl = (file) => new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result);
        reader.onerror = (err) => reject(err);
        reader.readAsDataURL(file);
    });
    const dataUrl = await toDataUrl(file);
    const res = await fetch('/api/upload-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ dataUrl })
    });
    const json = await res.json();
    if (!res.ok) {
        throw new Error(json.error || 'Image upload failed');
    }
    return json.url;
}

// Handles the purchase flow on the Shop page.
function attachShopEventHandlers() {
    const shopCards = document.querySelectorAll('.shop-card');
    if (!shopCards.length) return;

    shopCards.forEach(card => {
        const finish = card.dataset.finish;
        const fileInput = card.querySelector('.file-input');
        const nameInput = card.querySelector('.ship-name');
        const emailInput = card.querySelector('.ship-email');
        const line1Input = card.querySelector('.ship-line1');
        const line2Input = card.querySelector('.ship-line2');
        const cityInput = card.querySelector('.ship-city');
        const stateInput = card.querySelector('.ship-state');
        const zipInput = card.querySelector('.ship-zip');
        const countryInput = card.querySelector('.ship-country');
        const cardBtn = card.querySelector('.pay-card');
        const cryptoBtn = card.querySelector('.pay-crypto');

        async function collectDataAndUpload() {
            const file = fileInput.files[0];
            if (!file) {
                alert('Please upload your ultrasound image.');
                return null;
            }
            // validate shipping
            if (!nameInput.value || !emailInput.value || !line1Input.value || !cityInput.value || !stateInput.value || !zipInput.value || !countryInput.value) {
                alert('Please complete the shipping address.');
                return null;
            }
            // Upload the ultrasound to Cloudinary
            const imageUrl = await uploadImageToCloud(file);
            // Build shipping object
            const shipping = {
                name: nameInput.value,
                email: emailInput.value,
                line1: line1Input.value,
                line2: line2Input.value || '',
                city: cityInput.value,
                state: stateInput.value,
                zip: zipInput.value,
                country: countryInput.value
            };
            return { finish, imageUrl, shipping };
        }

        if (cardBtn) {
            cardBtn.addEventListener('click', async () => {
                // Visual loading state
                const original = cardBtn.textContent;
                cardBtn.textContent = 'Processing...';
                try {
                    const data = await collectDataAndUpload();
                    if (!data) return;
                    const res = await fetch('/api/create-checkout-session', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(data)
                    });
                    let json = null;
                    try {
                        json = await res.json();
                    } catch (_) {
                        // If response is not JSON (e.g. HTML error), read as text and throw generic error
                        const text = await res.text();
                        throw new Error('Unexpected response: ' + text.substring(0, 80));
                    }
                    if (!res.ok) {
                        throw new Error((json && json.error) || 'Checkout creation failed');
                    }
                    // Redirect to Stripe checkout
                    window.location.href = json.url;
                } catch (err) {
                    console.error(err);
                    alert('Card checkout failed: ' + err.message);
                } finally {
                    cardBtn.textContent = original;
                }
            });
        }
        if (cryptoBtn) {
            cryptoBtn.addEventListener('click', async () => {
                const original = cryptoBtn.textContent;
                cryptoBtn.textContent = 'Processing...';
                try {
                    const data = await collectDataAndUpload();
                    if (!data) return;
                    const res = await fetch('/api/create-crypto-charge', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(data)
                    });
                    let json = null;
                    try {
                        json = await res.json();
                    } catch (_) {
                        const text = await res.text();
                        throw new Error('Unexpected response: ' + text.substring(0, 80));
                    }
                    if (!res.ok) {
                        throw new Error((json && json.error) || 'Charge creation failed');
                    }
                    window.location.href = json.hosted_url;
                } catch (err) {
                    console.error(err);
                    alert('Crypto checkout failed: ' + err.message);
                } finally {
                    cryptoBtn.textContent = original;
                }
            });
        }
    });
}

// Partner and contact forms basic alerts
function attachFormHandlers() {
    const partnerForm = document.getElementById('partner-form');
    if (partnerForm) {
        partnerForm.addEventListener('submit', async function (e) {
            e.preventDefault();
            // Gather form data
            const formData = new FormData(partnerForm);
            const payload = {};
            formData.forEach((value, key) => {
                payload[key] = value;
            });
            try {
                const res = await fetch('/api/partner-interest', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                });
                const json = await res.json();
                if (!res.ok) throw new Error(json.error || 'Submission failed');
                alert('Thank you for your interest! We will be in touch soon with partnership details.');
                partnerForm.reset();
            } catch (err) {
                console.error(err);
                alert('Failed to send your request: ' + err.message);
            }
        });
    }
    const contactForm = document.getElementById('contact-form');
    if (contactForm) {
            contactForm.addEventListener('submit', function (e) {
                e.preventDefault();
                alert('Thank you for reaching out! We will respond shortly.');
                contactForm.reset();
            });
    }
}

document.addEventListener('DOMContentLoaded', () => {
    setCurrentYear();
    attachShopEventHandlers();
    attachFormHandlers();
});